package com.wilson2403.myapplicationprueba

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.wilson2403.myapplicationprueba.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.layout_user_row)
    }
}

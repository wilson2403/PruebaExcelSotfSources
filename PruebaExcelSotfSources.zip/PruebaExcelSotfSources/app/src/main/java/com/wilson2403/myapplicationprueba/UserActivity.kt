package com.wilson2403.myapplicationprueba

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.view.*
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.wilson2403.myapplicationprueba.Constants.REQUEST_CODE
import com.wilson2403.myapplicationprueba.Constants.RESULT_CODE
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class UserActivity : BaseActivity(), View.OnClickListener{
    lateinit var fab_addItem: FloatingActionButton
    lateinit var recyclerView: RecyclerView
    lateinit var userAdapter: UserListAdapter
    lateinit var progerssProgressDialog: ProgressDialog
    var userList = ArrayList<User>()
    var position: Int = 0
    lateinit var swipeRefreshLayout: SwipeRefreshLayout
    lateinit var toast: Toast
    lateinit var thread: Thread

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user)
        initialise()
    }

    private fun initialise() {
        super.init()
        toolbar?.setTitle("User")

        /* To hide navigationIcon */
        supportActionBar?.setDisplayHomeAsUpEnabled(false)

        fab_addItem = findViewById(R.id.fab_addItem)
        recyclerView = findViewById(R.id.recyclerView)
        fab_addItem.setOnClickListener(this)
        recyclerView.layoutManager = LinearLayoutManager(this, RecyclerView.VERTICAL, false)
        progerssProgressDialog = ProgressDialog(this)
        progerssProgressDialog.setTitle("Loading")
        progerssProgressDialog.setMessage("Please Wait...")
        progerssProgressDialog.setCancelable(false)
        progerssProgressDialog.show()

        try {

            fetchData()
            userAdapter = UserListAdapter(this, userList, {user,position -> onItemClicked(user,position)})
            recyclerView.adapter = userAdapter;

        } catch (e: Exception) {
            e.printStackTrace()
        }

        swipeRefreshLayout = findViewById(R.id.swipeContainer)
        swipeRefreshLayout.setOnRefreshListener {
            Handler().postDelayed(Runnable {
                swipeRefreshLayout.isRefreshing = false
            }, 4000)
        }
    }

    /* To hide menu */
    override fun onPrepareOptionsMenu(menu: Menu?): Boolean {
        var deleteItem = menu!!.findItem(R.id.menu_delete)
        deleteItem.setVisible(false)
        return true
    }

    private fun fetchData() {
        val call: Call<List<User>> = ApiClient.create().getUsers()
        call.enqueue(object : Callback<List<User>> {
            override fun onFailure(call: Call<List<User>>, t: Throwable) {
                progerssProgressDialog.dismiss()
                Utilities.showAlert(this@UserActivity, getString(R.string.check_internet_connection))
            }

            override fun onResponse(call: Call<List<User>>?, response: Response<List<User>>?) {
                progerssProgressDialog.dismiss()

                try {
                    if (response != null && response.isSuccessful && response.body() != null) {
                        userList.addAll(response!!.body()!!)
                        recyclerView.adapter!!.notifyDataSetChanged()
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        })
        displayValue(0);
    }

    fun displayValue(value: Int) {
        val newValue = value + 1
        toast = Toast.makeText(this, "New value is: $newValue", Toast.LENGTH_SHORT)
        thread = Thread(Runnable {
            toast.show()
        })
        thread.start()
    }

    private fun onItemClicked(user: User, position: Int){

        this.position = position
        var intent = Intent(this, UserDetailsActivity::class.java)
        intent.putExtra("id",user.id)
        intent.putExtra("title",user.title)
        intent.putExtra("body",user.body)
        startActivityForResult(intent, REQUEST_CODE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(resultCode.equals(RESULT_CODE)){
            try{
                userAdapter.removeItem(position)
                Toast.makeText(this, R.string.user_deleted, Toast.LENGTH_LONG).show()

            }catch (e: Exception){
                e.printStackTrace()
            }
        }
    }

    override fun onClick(view: View?) {
        if (view != null) {
            when (view.id) {
                R.id.fab_addItem -> {
                    var dialog = AddItemDialog(this)
                    dialog.show()
                    dialog.window!!.setLayout(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )

                    dialog.onAddItem(object : AddItemDialog.IAddItemCallback {
                        override fun addItem(user: User) {

                            userAdapter.addItem(user)

                        }
                    })
                }
            }
        }
    }
}


package com.wilson2403.myapplicationprueba

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import com.wilson2403.myapplicationprueba.Constants.RESULT_CODE
import com.wilson2403.myapplicationprueba.R
import java.lang.Exception

class UserDetailsActivity : BaseActivity(){

    var id: String = ""
    var title: String = ""
    var body: String = ""
    private var mScaleGestureDetector: ScaleGestureDetector? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_details)

        initialise()
    }

    private fun initialise(){
        super.init()
        try{
            var intent = getIntent()
            if(intent != null){
                if(intent.hasExtra("id")){
                    id = intent.getStringExtra("id").toString()
                }
                if(intent.hasExtra("title")){
                    title = intent.getStringExtra("title").toString()
                }
                if(intent.hasExtra("body")){
                    body = intent.getStringExtra("body").toString()
                }
            }
            var idtv = findViewById<TextView>(R.id.id)
            var titletv = findViewById<TextView>(R.id.title)
            var bodytv = findViewById<TextView>(R.id.body)
            var reverse = title.reversed().uppercase()
            try {
                idtv.text = "User Id: "+ id
                titletv.text = "Name: "+ title
                bodytv.text = "Inverted Name: "+ reverse
            } catch (e: Exception) {
                e.printStackTrace()
            }
            Toast.makeText(this, "Inverted name: " +reverse, Toast.LENGTH_LONG).show()
        }catch (e: Exception){
            e.printStackTrace()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean{
        when (item.itemId){
            R.id.menu_delete ->{
                var intent = Intent(this, UserActivity::class.java)
                setResult(RESULT_CODE, intent)
                finish()

                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    override fun onTouchEvent(event: MotionEvent?): Boolean {
        mScaleGestureDetector!!.onTouchEvent(event)
        return true
    }

}
